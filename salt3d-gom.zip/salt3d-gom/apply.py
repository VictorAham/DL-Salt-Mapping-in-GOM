"""Apply trained models to a seismic volume.

Examples
--------
Ensemble of the four models on the Mississippi Canyon volume, scored against its
reference mask (Table 5):
    python apply.py --seismic data/test-mississippi/seismic.h5 \\
        --weights outputs/perturbation/base_model_best_dice.h5 \\
                  outputs/perturbation/seismic_model_best_dice.h5 \\
                  outputs/perturbation/label_model_best_dice.h5 \\
                  outputs/perturbation/joint_model_best_dice.h5 \\
        --labels data/test-mississippi/mississippi_salt.h5 --save-each \\
        --out outputs/mississippi/prob.h5

Configuration A (all three seeds) on the same volume:
    python apply.py --seismic data/test-mississippi/seismic.h5 --arch plain_unet \\
        --weights outputs/ablation/config_A/seed_42/best.h5 \\
                  outputs/ablation/config_A/seed_123/best.h5 \\
                  outputs/ablation/config_A/seed_7/best.h5 \\
        --labels data/test-mississippi/mississippi_salt.h5 --save-each \\
        --out outputs/mississippi/config_A.h5

Viosca Knoll probability volume and geobody (Figs. 13-14):
    python apply.py --seismic data/train_val-vk/seismic.h5 --weights <four checkpoints> \\
        --survey-mask --geobody outputs/vk/geobody.h5 --out outputs/vk/prob.h5
"""
import argparse
import csv
import os

import numpy as np

from salt3d import config as C
from salt3d.utils import configure_gpu, ensure_dir, load_cube, save_cube


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--seismic", required=True, help="seismic volume (HDF5, dataset 'cube')")
    p.add_argument("--weights", nargs="+", required=True, help="one or more checkpoints; several = ensemble mean")
    p.add_argument("--arch", default="se_resunet", choices=["plain_unet", "resunet", "se_resunet"],
                   help="architecture of the checkpoints (A: plain_unet, B: resunet, C-G/base/perturbed: se_resunet)")
    p.add_argument("--out", required=True, help="output HDF5 for the (ensemble) probability volume")
    p.add_argument("--save-each", action="store_true", help="also save each model's probability volume")
    p.add_argument("--max-depth-ft", type=float, default=C.INFERENCE["max_depth_ft"])
    p.add_argument("--stride", type=int, default=C.INFERENCE["stride"])
    p.add_argument("--batch-size", type=int, default=C.INFERENCE["batch_size"])
    p.add_argument("--survey-mask", action="store_true",
                   help="zero predictions where the seismic amplitude is exactly 0 "
                        "(used for Viosca Knoll renderings, not for Table 5)")
    p.add_argument("--labels", default=None, help="reference mask (HDF5) to score against")
    p.add_argument("--label-threshold", type=float, default=0.0, help="reference voxels above this are salt")
    p.add_argument("--keep-unlabelled-inlines", action="store_true",
                   help="score all inlines, including those without any reference label")
    p.add_argument("--boundary-width", type=int, default=C.EVAL_BOUNDARY_WIDTH)
    p.add_argument("--geobody", default=None, help="write the postprocessed geobody (HDF5) of the ensemble")
    return p.parse_args()


def main():
    args = parse_args()
    configure_gpu()
    import tensorflow as tf
    from salt3d.evaluation import evaluate_volume, prepare_reference
    from salt3d.inference import predict_salt_prob
    from salt3d.models import build_for_inference

    X = load_cube(args.seismic)
    print(f"Seismic volume: {X.shape}")
    kw = dict(patch_size=C.PATCH_SIZE, stride=args.stride, batch_size=args.batch_size,
              max_depth_ft=args.max_depth_ft, survey_mask=args.survey_mask)

    ref = rows = None
    if args.labels:
        ref, rows = prepare_reference(load_cube(args.labels), max_depth_ft=args.max_depth_ft,
                                      label_threshold=args.label_threshold,
                                      exclude_unlabelled_inlines=not args.keep_unlabelled_inlines)
        print(f"Reference: {ref.shape} on {len(rows)} inlines | salt fraction {ref.mean():.4f}")

    ensure_dir(os.path.dirname(os.path.abspath(args.out)))
    stem, _ = os.path.splitext(args.out)
    total, scores = None, []
    for n, w in enumerate(args.weights):
        print(f"\n=== Model {n + 1}/{len(args.weights)}: {w} ===")
        tf.keras.backend.clear_session()
        model = build_for_inference(args.arch)
        model.load_weights(w)
        prob = predict_salt_prob(model, X, **kw)
        if args.save_each:
            save_cube(f"{stem}_model{n + 1}.h5", prob)
        if ref is not None:
            scores.append({"Model": os.path.basename(w), **evaluate_volume(prob, ref, rows, bw=args.boundary_width)})
            print({k: round(v, 4) for k, v in scores[-1].items() if k != "Model"})
        total = prob if total is None else total + prob
        del model

    ens = total / len(args.weights)
    save_cube(args.out, ens)
    if ref is not None:
        if len(args.weights) > 1:
            scores.append({"Model": "Ensemble", **evaluate_volume(ens, ref, rows, bw=args.boundary_width)})
        if len(args.weights) > 1 and len(scores) > 1:
            vals = np.array([[s[k] for k in ("soft_dice", "mean_iou", "boundary_iou")] for s in scores[:-1]])
            print(f"\nAcross models: soft Dice {vals[:, 0].mean():.4f} ± {vals[:, 0].std():.4f}, "
                  f"mean IoU {vals[:, 1].mean():.4f} ± {vals[:, 1].std():.4f}")
        path = f"{stem}_metrics.csv"
        with open(path, "w", newline="") as f:
            wtr = csv.DictWriter(f, fieldnames=list(scores[0]))
            wtr.writeheader()
            wtr.writerows([{k: (round(v, 4) if isinstance(v, float) else v) for k, v in s.items()}
                           for s in scores])
        print(f"Saved metrics: {path}")

    if args.geobody:
        from salt3d.postprocess import extract_geobody
        geobody = extract_geobody(ens, **C.POSTPROCESS)
        save_cube(args.geobody, geobody.astype(np.uint8), key="geobody")
        print(f"Geobody voxels: {int(geobody.sum()):,}")


if __name__ == "__main__":
    main()
