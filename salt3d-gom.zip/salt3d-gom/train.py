"""Training entry point.

Examples
--------
Sequential ablation (Table 4), all configurations and seeds:
    python train.py ablation
One configuration and seed:
    python train.py ablation --configs E --seeds 42
Base model (Configuration E, seed 42) used to initialise the perturbation runs:
    python train.py base
Perturbation fine-tuning from the base model (Table 3):
    python train.py perturb --mode seismic
    python train.py perturb --mode label
    python train.py perturb --mode joint
Ensemble of the four models on the validation patches:
    python train.py ensemble-eval
"""
import argparse
import csv
import json
import os

import numpy as np

from salt3d import config as C
from salt3d.utils import configure_gpu, ensure_dir, load_cube, save_history, save_json


def parse_args():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--seismic", default="data/train_val-vk/seismic.h5", help="Viosca Knoll seismic (HDF5)")
    p.add_argument("--labels", default="data/train_val-vk/salt.h5", help="Viosca Knoll salt mask (HDF5)")
    p.add_argument("--out", default="outputs", help="output directory")
    p.add_argument("--epochs", type=int, default=C.EPOCHS)
    p.add_argument("--no-depth-sample-weights", action="store_true",
                   help="do NOT pass depth-bin labels as Keras sample weights "
                        "(the reported runs did; see README)")
    sub = p.add_subparsers(dest="command", required=True)
    a = sub.add_parser("ablation", help="sequential ablation, Configurations A-G")
    a.add_argument("--configs", nargs="+", default=list("ABCDEFG"))
    a.add_argument("--seeds", nargs="+", type=int, default=list(C.TRAIN_SEEDS))
    sub.add_parser("base", help="base model (Configuration E, seed 42)")
    pp = sub.add_parser("perturb", help="perturbation fine-tuning from the base model")
    pp.add_argument("--mode", choices=["seismic", "label", "joint"], required=True)
    pp.add_argument("--init", default=None, help="base checkpoint (default: <out>/perturbation/base_model_best_dice.h5)")
    e = sub.add_parser("ensemble-eval", help="score the 4-model ensemble on the validation patches")
    e.add_argument("--checkpoints", nargs="+", default=None)
    return p.parse_args()


def load_split(args):
    from salt3d.data import split_train_val
    X = load_cube(args.seismic)
    y = load_cube(args.labels)
    return split_train_val(X, y)


def maybe_drop_weights(gen, args):
    from salt3d.data import NoSampleWeights
    return NoSampleWeights(gen) if args.no_depth_sample_weights else gen


def run_ablation(args, X_train, y_train, X_val, y_val):
    import tensorflow as tf
    from salt3d.callbacks import ablation_callbacks, best_epoch_metrics
    from salt3d.data import DepthWeightedGeneratorWrapper, build_generators
    from salt3d.models import ABLATION_CONFIGS

    out_root = ensure_dir(os.path.join(args.out, "ablation"))
    summary_path = os.path.join(out_root, "ablation_results.json")
    results = json.load(open(summary_path)) if os.path.exists(summary_path) else {}

    for key in args.configs:
        cfg = ABLATION_CONFIGS[key]
        print(f"\n=== {cfg['label']} ===")
        runs = []
        for seed in args.seeds:
            print(f"\n  Configuration {key} | seed {seed}")
            tf.keras.backend.clear_session()
            tr, vl = build_generators(X_train, y_train, X_val, y_val, train_seed=seed,
                                      val_seed=C.VAL_SEED, depth_stratified=cfg["depth_stratified"])
            if cfg["depth_weighted"]:
                tr = DepthWeightedGeneratorWrapper(tr)
            run_dir = os.path.join(out_root, f"config_{key}", f"seed_{seed}")
            model = cfg["build"]()
            cbs, depth_cb = ablation_callbacks(run_dir, vl, depth_weighted=cfg["depth_weighted"])
            history = model.fit(maybe_drop_weights(tr, args), validation_data=maybe_drop_weights(vl, args),
                                epochs=args.epochs, callbacks=cbs, verbose=1)
            m = best_epoch_metrics(history, depth_weighted=cfg["depth_weighted"])
            m["seed"] = seed
            runs.append(m)
            save_history(os.path.join(run_dir, "history.json"), history)
            save_json(os.path.join(run_dir, "depth_metrics.json"), depth_cb.as_dict())
            print(f"  → Dice={m['dice']:.4f}  mIoU={m['mean_iou']:.4f}  bIoU={m['boundary_iou']:.4f}"
                  f"  (epoch {m['best_epoch']})")
        results[key] = runs
        save_json(summary_path, results)

    rows = []
    for key in sorted(results):
        r = results[key]
        row = {"Config": key, "Label": ABLATION_CONFIGS[key]["label"], "Seeds": len(r)}
        for metric in ("dice", "mean_iou", "boundary_iou"):
            v = [x[metric] for x in r]
            row[f"{metric}_mean"] = round(float(np.mean(v)), 4)
            row[f"{metric}_sd"] = round(float(np.std(v)), 4)
        rows.append(row)
    with open(os.path.join(out_root, "ablation_summary.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    print(f"\nSaved: {os.path.join(out_root, 'ablation_summary.csv')}")


def run_base(args, X_train, y_train, X_val, y_val):
    import tensorflow as tf
    from salt3d.callbacks import best_epoch_metrics, perturbation_callbacks
    from salt3d.data import build_generators
    from salt3d.losses import salt_ultimate_loss
    from salt3d.models import resunet_3d

    out_dir = ensure_dir(os.path.join(args.out, "perturbation"))
    tr, vl = build_generators(X_train, y_train, X_val, y_val, train_seed=C.BASE_SEED,
                              val_seed=C.VAL_SEED, depth_stratified=True)
    tf.keras.backend.clear_session()
    model = resunet_3d(use_se=True, loss_fn=salt_ultimate_loss, lr=C.LEARNING_RATE)
    cbs, depth_cb = perturbation_callbacks(out_dir, "base_model", vl)
    history = model.fit(maybe_drop_weights(tr, args), validation_data=maybe_drop_weights(vl, args),
                        epochs=args.epochs, callbacks=cbs, verbose=1)
    model.save(os.path.join(out_dir, "base_model_final.h5"))
    save_history(os.path.join(out_dir, "base_model_history.json"), history)
    save_json(os.path.join(out_dir, "base_model_depth_metrics.json"), depth_cb.as_dict())
    save_json(os.path.join(out_dir, "base_model_best.json"), best_epoch_metrics(history))


def run_perturb(args, X_train, y_train, X_val, y_val):
    import tensorflow as tf
    from salt3d.callbacks import best_epoch_metrics, perturbation_callbacks
    from salt3d.data import build_generators, drop_sample_weights
    from salt3d.losses import salt_ultimate_loss
    from salt3d.models import resunet_3d
    from salt3d.perturbation import label_perturbation_gen, seismic_perturbation_gen

    out_dir = ensure_dir(os.path.join(args.out, "perturbation"))
    init = args.init or os.path.join(out_dir, "base_model_best_dice.h5")
    if not os.path.exists(init):
        raise FileNotFoundError(f"Base checkpoint not found: {init} (run 'python train.py base' first)")
    tr, vl = build_generators(X_train, y_train, X_val, y_val, train_seed=C.BASE_SEED,
                              val_seed=C.VAL_SEED, depth_stratified=True)
    p = C.PERTURBATION[args.mode]
    gen = tr
    if p["label_prob"] is not None:
        gen = label_perturbation_gen(gen, perturbation_prob=p["label_prob"])
    if p["seismic_prob"] is not None:
        gen = seismic_perturbation_gen(gen, perturbation_prob=p["seismic_prob"])
    if args.no_depth_sample_weights:
        gen = drop_sample_weights(gen)

    tf.keras.backend.clear_session()
    model = resunet_3d(use_se=True, loss_fn=salt_ultimate_loss, lr=C.LEARNING_RATE)  # new Adam, lr 1e-4
    model.load_weights(init)
    name = f"{args.mode}_model"
    cbs, depth_cb = perturbation_callbacks(out_dir, name, vl)
    history = model.fit(gen, validation_data=maybe_drop_weights(vl, args), steps_per_epoch=len(tr),
                        epochs=args.epochs, callbacks=cbs, verbose=1)
    model.save(os.path.join(out_dir, f"{name}_final.h5"))
    save_history(os.path.join(out_dir, f"{name}_history.json"), history)
    save_json(os.path.join(out_dir, f"{name}_depth_metrics.json"), depth_cb.as_dict())
    save_json(os.path.join(out_dir, f"{name}_best.json"), best_epoch_metrics(history))


def run_ensemble_eval(args, X_train, y_train, X_val, y_val):
    import tensorflow as tf
    from salt3d.data import build_generators
    from salt3d.evaluation import ensemble_validation_metrics
    from salt3d.models import build_for_inference

    out_dir = os.path.join(args.out, "perturbation")
    ckpts = args.checkpoints or [os.path.join(out_dir, f"{n}_model_best_dice.h5")
                                 for n in ("base", "seismic", "label", "joint")]
    _, vl = build_generators(X_train, y_train, X_val, y_val, train_seed=C.BASE_SEED,
                             val_seed=C.VAL_SEED, depth_stratified=True)
    tf.keras.backend.clear_session()
    models = []
    for c in ckpts:
        m = build_for_inference("se_resunet")
        m.load_weights(c)
        models.append(m)
        print(f"  Loaded {c}")
    res = ensemble_validation_metrics(models, vl)
    print(json.dumps(res, indent=2))
    save_json(os.path.join(out_dir, "ensemble_validation_metrics.json"), res)


def main():
    args = parse_args()
    configure_gpu()
    data = load_split(args)
    {"ablation": run_ablation, "base": run_base, "perturb": run_perturb,
     "ensemble-eval": run_ensemble_eval}[args.command](args, *data[:4])


if __name__ == "__main__":
    main()
