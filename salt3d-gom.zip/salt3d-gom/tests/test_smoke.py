"""Smoke test on a small synthetic volume (CPU, ~1-2 minutes).

    python -m tests.test_smoke

Checks that every module runs end to end; it does not reproduce any result.
"""
import numpy as np
import tensorflow as tf

from salt3d.callbacks import best_epoch_metrics
from salt3d.data import DepthWeightedGeneratorWrapper, NoSampleWeights, build_generators, split_train_val
from salt3d.evaluation import evaluate_volume, prepare_reference
from salt3d.inference import predict_salt_prob
from salt3d.losses import (balanced_cross_entropy, boundary_dice_loss, distance_weighted_bce,
                           salt_ultimate_loss, soft_dice_loss)
from salt3d.models import plain_unet_3d, resunet_3d
from salt3d.perturbation import label_perturbation_gen, seismic_perturbation_gen
from salt3d.postprocess import extract_geobody

P = (32, 32, 32)
rng = np.random.default_rng(0)


def synthetic_volume(shape=(64, 1200, 1300)):
    """Noise with a few salt blobs at shallow, mid and deep levels."""
    X = rng.normal(0, 0.3, shape).astype(np.float32)
    y = np.zeros(shape, np.float32)
    for (i, j, k, r) in [(32, 150, 300, 14), (32, 400, 600, 18), (32, 700, 950, 16), (32, 1000, 1150, 12)]:
        ii, jj, kk = np.ogrid[:shape[0], :shape[1], :shape[2]]
        blob = (ii - i) ** 2 + (jj - j) ** 2 + (kk - k) ** 2 < r ** 2
        y[blob] = 1.0
        X[blob] += 1.0
    return X, y


def main():
    tf.random.set_seed(0)
    X, y = synthetic_volume()
    X_tr, y_tr, X_vl, y_vl, _ = split_train_val(X, y, xl_split=800, buffer_xl=5)
    tr, vl = build_generators(X_tr, y_tr, X_vl, y_vl, train_seed=42, val_seed=999,
                              depth_stratified=True, patch_size=P)
    assert len(tr.indices) > 0 and len(vl.indices) > 0
    Xb, Yb, dl = tr[0]
    assert Xb.shape[1:] == P + (1,) and len(dl) == len(Xb)
    print("generators OK:", len(tr.indices), "train /", len(vl.indices), "val patches")

    # Loss terms and gradient check (boundary Dice must give no gradient)
    m = resunet_3d(input_shape=P + (1,), use_se=True, loss_fn=salt_ultimate_loss)
    xb, yb = tf.constant(Xb), tf.constant(Yb)
    for name, fn in [("soft Dice", soft_dice_loss), ("balanced BCE", balanced_cross_entropy),
                     ("boundary Dice", boundary_dice_loss), ("distance-weighted BCE", distance_weighted_bce)]:
        with tf.GradientTape() as tape:
            loss = fn(yb, m(xb, training=False))
        live = [g for g in tape.gradient(loss, m.trainable_variables) if g is not None]
        print(f"  {name:22s} loss {float(loss):.4f}  weights with gradient {len(live)}/{len(m.trainable_variables)}")
        assert np.isfinite(float(loss))
        assert (len(live) == 0) == (name == "boundary Dice")

    # One short fit per training path. Under Keras 3 the depth-label output cannot be
    # passed as sample weights (it is a Python list, as in the original runs under
    # Keras 2), so the fits use the NoSampleWeights wrapper there.
    keras3 = int(tf.keras.__version__.split(".")[0]) >= 3 if hasattr(tf.keras, "__version__") else False
    wrap = NoSampleWeights if keras3 else (lambda g: g)
    print(f"  Keras {'3' if keras3 else '2'}: fitting {'without' if keras3 else 'with'} depth sample weights")
    for label, model, gen, val in [
        ("plain U-Net", plain_unet_3d(input_shape=P + (1,)), wrap(tr), wrap(vl)),
        ("SE-ResUNet composite", resunet_3d(input_shape=P + (1,), use_se=True, loss_fn=salt_ultimate_loss),
         wrap(tr), wrap(vl)),
        ("SE-ResUNet, no sample weights", resunet_3d(input_shape=P + (1,), use_se=True,
                                                     loss_fn=salt_ultimate_loss), NoSampleWeights(tr), NoSampleWeights(vl)),
    ]:
        h = model.fit(gen, validation_data=val, epochs=1, steps_per_epoch=2, verbose=0)
        print(f"  fit OK: {label:30s}", best_epoch_metrics(h))

    from salt3d.losses import METRICS_F, salt_ultimate_loss_depth_weighted
    fg_small = resunet_3d(input_shape=P + (1,), use_se=True, compile_model=False)
    fg_small.compile(optimizer="adam", loss=salt_ultimate_loss_depth_weighted, metrics=METRICS_F)
    h = fg_small.fit(wrap(DepthWeightedGeneratorWrapper(tr)), validation_data=wrap(vl), epochs=1, steps_per_epoch=2, verbose=0)
    print("  fit OK: depth-weighted (F/G)          ", best_epoch_metrics(h, depth_weighted=True))

    # Perturbation generators
    for name, gen in [("seismic", seismic_perturbation_gen(tr, 0.75)), ("label", label_perturbation_gen(tr, 0.5)),
                      ("joint", seismic_perturbation_gen(label_perturbation_gen(tr, 0.5), 0.5))]:
        a, b, c = next(gen)
        assert a.shape == Xb.shape and b.shape == Yb.shape and np.isfinite(a).all()
        print(f"  perturbation OK: {name}")

    # Prediction, evaluation, postprocessing on a small volume
    vol, lab = X[:, 360:440, 560:640], y[:, 360:440, 560:640]      # region containing a salt blob
    prob = predict_salt_prob(m, vol, patch_size=P, stride=32, batch_size=8, verbose=False)
    assert prob.shape == vol.shape and 0 <= prob.min() and prob.max() <= 1
    ref, rows = prepare_reference(lab, max_depth_ft=40000)
    assert ref.sum() > 0, "test region must contain salt"
    scores = evaluate_volume(prob, ref, rows)
    print(f"  prediction + evaluation OK on {len(rows)} labelled inlines:",
          {k: round(v, 3) for k, v in scores.items()})
    full = np.zeros(lab.shape, np.float32)
    full[rows] = ref                                                  # a perfect prediction
    perfect = evaluate_volume(full, ref, rows)
    assert perfect["soft_dice"] > 0.999 and perfect["false_positive_rate"] == 0.0
    geo = extract_geobody(lab, min_component_voxels=10)
    assert geo.sum() > 0
    print(f"  geobody OK: {int(geo.sum())} voxels (reference salt: {int(lab.sum())})")
    print("\nAll smoke tests passed.")


if __name__ == "__main__":
    main()
