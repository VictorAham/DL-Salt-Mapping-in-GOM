"""Training-time augmentation of seismic/mask patch pairs."""
import numpy as np


def advanced_seismic_augmentation(data, mask, alpha=15, sigma=3):
    """Random geometric and amplitude augmentation of a (inline, crossline, depth) patch.

    Applied independently to every training patch:
      1. flip along the inline and along the crossline axis (probability 0.4 each);
      2. rotation by 90, 180 or 270 degrees in the inline-crossline plane (p = 0.4);
      3. transposition of inline and crossline axes (p = 0.4);
      4. amplitude scaling by a factor drawn from U[0.1, 0.4] (p = 0.4).
    The depth axis is never flipped or rotated. ``alpha`` and ``sigma`` are kept
    for signature compatibility only; no elastic deformation is applied.
    """
    # 1. Axis flips (inline, crossline)
    for axis in [0, 1]:
        if np.random.rand() < 0.4:
            data = np.flip(data, axis=axis)
            mask = np.flip(mask, axis=axis)

    # 2. 90-degree rotations in the horizontal plane
    if np.random.rand() < 0.4:
        k = np.random.randint(1, 4)
        data = np.rot90(data, k=k, axes=(0, 1))
        mask = np.rot90(mask, k=k, axes=(0, 1))

    # 3. Transpose inline/crossline (acquisition-orientation variability)
    if np.random.rand() < 0.4:
        data = data.transpose(1, 0, 2)
        mask = mask.transpose(1, 0, 2)

    # 4. Amplitude dimming (weakly imaged reflectivity)
    if np.random.rand() < 0.4:
        data = data * np.random.uniform(0.1, 0.4)

    return data.astype(np.float32), mask.astype(np.float32)
