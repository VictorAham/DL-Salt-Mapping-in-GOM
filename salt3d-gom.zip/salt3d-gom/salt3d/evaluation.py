"""Evaluation of probability volumes against reference masks (NumPy)."""
import numpy as np
from scipy.ndimage import binary_dilation

from . import config as C


def np_soft_dice(y_true, y_pred, smooth=1e-6):
    yt = y_true.ravel().astype(np.float32)
    yp = y_pred.ravel().astype(np.float32)
    return float((2.0 * np.sum(yt * yp) + smooth) / (np.sum(yt ** 2) + np.sum(yp ** 2) + smooth))


def np_mean_iou(y_true, y_pred, thr=C.THRESHOLD, smooth=1e-6):
    yt, yp = y_true > thr, y_pred > thr
    i = np.sum(yt & yp)
    return float((i + smooth) / (np.sum(yt) + np.sum(yp) - i + smooth))


def np_boundary_iou(y_true, y_pred, thr=C.THRESHOLD, bw=C.EVAL_BOUNDARY_WIDTH, smooth=1e-6):
    """IoU of the bands of width ``bw`` voxels immediately outside reference and prediction."""
    struct = np.ones((2 * bw + 1,) * 3, dtype=bool)

    def band(m):
        b = m > thr
        return binary_dilation(b, structure=struct) & ~b

    bt, bp = band(y_true), band(y_pred)
    i = np.sum(bt & bp)
    return float((i + smooth) / (np.sum(bt) + np.sum(bp) - i + smooth))


def confusion(y_true, y_pred, thr=C.THRESHOLD):
    t, p = y_true > 0.5, y_pred > thr
    tp, fp = int(np.sum(t & p)), int(np.sum(~t & p))
    fn, tn = int(np.sum(t & ~p)), int(np.sum(~t & ~p))
    return dict(precision=tp / max(tp + fp, 1), recall=tp / max(tp + fn, 1),
                binary_dice=2 * tp / max(2 * tp + fp + fn, 1),
                false_positive_rate=fp / max(fp + tn, 1))


def prepare_reference(mask, max_depth_ft=C.MAX_DEPTH_FT, label_threshold=0.0,
                      exclude_unlabelled_inlines=True):
    """Binary reference for volume evaluation.

    Every voxel above ``label_threshold`` is salt (the stored masks mark the
    salt-flood velocity). The volume is cut at ``max_depth_ft``. With
    ``exclude_unlabelled_inlines``, inlines without any label are excluded from
    both reference and prediction (Mississippi Canyon: 20 of 1,201 inlines).
    Returns (reference, inline_index) — index the prediction with the same rows.
    """
    depth = min(int(max_depth_ft / C.DZ_FT), mask.shape[2])
    ref = (np.nan_to_num(mask[:, :, :depth]) > label_threshold).astype(np.float32)
    rows = np.arange(mask.shape[0])
    if exclude_unlabelled_inlines:
        rows = rows[ref.reshape(ref.shape[0], -1).any(axis=1)]
        ref = ref[rows]
    return ref, rows


def evaluate_volume(prob, reference, rows, bw=C.EVAL_BOUNDARY_WIDTH, thr=C.THRESHOLD):
    """Soft Dice (raw probabilities), IoU and boundary IoU (threshold ``thr``), plus
    precision, recall and false-positive rate, on the rows/depths of the reference."""
    yp = prob[rows][:, :, :reference.shape[2]].astype(np.float32)
    out = dict(soft_dice=np_soft_dice(reference, yp), mean_iou=np_mean_iou(reference, yp, thr),
               boundary_iou=np_boundary_iou(reference, yp, thr, bw))
    out.update(confusion(reference, yp, thr))
    return out


def ensemble_validation_metrics(models, val_gen, thr=C.THRESHOLD, bw=C.EVAL_BOUNDARY_WIDTH):
    """Ensemble (mean probability) scored per validation patch and averaged, as reported
    for the Viosca Knoll ensemble. Not directly comparable with Keras batch-level metrics."""
    dice, miou, biou = [], [], []
    for i in range(len(val_gen)):
        Xv, yt, *_ = val_gen[i]
        avg = np.mean([m.predict(Xv, verbose=0) for m in models], axis=0)
        for j in range(len(Xv)):
            t, p = np.squeeze(yt[j]), np.squeeze(avg[j])
            pb = (p > thr).astype(np.float32)
            dice.append((2 * np.sum(t * p) + 1e-6) / (np.sum(t ** 2) + np.sum(p ** 2) + 1e-6))
            inter = np.sum(t * pb)
            miou.append((inter + 1e-6) / (np.sum(t) + np.sum(pb) - inter + 1e-6))
            biou.append(np_boundary_iou(t, pb, thr=0.5, bw=bw))
    return dict(soft_dice=float(np.mean(dice)), mean_iou=float(np.mean(miou)),
                boundary_iou=float(np.mean(biou)), n_patches=len(dice))
