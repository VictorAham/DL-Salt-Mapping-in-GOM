"""Whole-volume prediction by overlapping patches blended with a 3D Gaussian taper."""
import gc

import numpy as np
from scipy.signal.windows import gaussian

from . import config as C

try:
    from tqdm.auto import tqdm
except ImportError:  # tqdm is optional
    def tqdm(x, **kwargs):
        return x


def get_3d_taper(size=128):
    """3D Gaussian weight window (std = size / 4) that suppresses patch-edge artefacts."""
    g1d = gaussian(size, std=size / 4).reshape(size, 1, 1)
    return (g1d * g1d.transpose(1, 0, 2) * g1d.transpose(1, 2, 0)).astype(np.float32)


def _coords(total_len, patch_len, step):
    """Patch start positions covering 0 … total_len - patch_len, including the last edge."""
    if total_len <= patch_len:
        return [0]
    coords = list(range(0, total_len - patch_len, step))
    coords.append(total_len - patch_len)
    return sorted(set(coords))


def normalize_patch(patch):
    """Per-patch standardisation used at prediction time: z-score, clip to ±2, divide by 2."""
    p_std = np.std(patch)
    if p_std < 1e-5:
        return np.zeros_like(patch)
    return np.clip((patch - np.mean(patch)) / (p_std + 1e-6), -2.0, 2.0) / 2.0


def predict_salt_prob(model, X, patch_size=C.PATCH_SIZE, stride=64, batch_size=4,
                      max_depth_ft=None, pad=64, survey_mask=False, verbose=True):
    """Salt-probability volume for a seismic volume X (inline, crossline, depth).

    The volume is truncated at ``max_depth_ft`` (if given), NaNs are set to 0, and
    the volume is reflect-padded by ``pad`` voxels on every side. Patches are
    predicted with the given stride, weighted by a 3D Gaussian taper, averaged,
    cropped back to the input size and clipped to [0, 1].
    ``survey_mask=True`` sets the prediction to 0 wherever the input amplitude is
    exactly 0 (outside the survey footprint). The Mississippi Canyon results
    (Table 5) were computed with survey_mask=False; the Viosca Knoll volume
    renderings used survey_mask=True.
    """
    pi, px, pz = patch_size
    taper = get_3d_taper(pi)
    if max_depth_ft is not None:
        X = X[:, :, :min(X.shape[2], int(max_depth_ft // C.DZ_FT))]
    orig_shape = X.shape
    X_clean = np.nan_to_num(X, nan=0.0)
    X_padded = np.pad(X_clean, ((pad, pad),) * 3, mode="reflect")
    ps = X_padded.shape
    indices = [(i, j, k) for i in _coords(ps[0], pi, stride)
               for j in _coords(ps[1], px, stride) for k in _coords(ps[2], pz, stride)]
    if verbose:
        print(f"Input {orig_shape} | padded {ps} | patches {len(indices)}")

    pred = np.zeros(ps, dtype=np.float32)
    weight = np.zeros(ps, dtype=np.float32)
    for n in tqdm(range(0, len(indices), batch_size), desc="Predicting", disable=not verbose):
        batch_idx = indices[n:n + batch_size]
        batch = np.array([normalize_patch(X_padded[i:i + pi, j:j + px, k:k + pz])[..., None]
                          for i, j, k in batch_idx], dtype=np.float32)
        out = np.asarray(model.predict_on_batch(batch))
        if out.ndim == 4:
            out = out[None]
        for b, (i, j, k) in enumerate(batch_idx):
            pred[i:i + pi, j:j + px, k:k + pz] += np.nan_to_num(np.squeeze(out[b])) * taper
            weight[i:i + pi, j:j + px, k:k + pz] += taper
        if n % 500 == 0:
            gc.collect()

    np.divide(pred, weight, out=pred, where=weight > 0)
    del weight
    result = pred[pad:pad + orig_shape[0], pad:pad + orig_shape[1], pad:pad + orig_shape[2]].copy()
    del pred, X_padded
    if survey_mask:
        result[X_clean == 0.0] = 0.0
    gc.collect()
    return np.clip(result, 0.0, 1.0)


def ensemble_predict(models, X, **kwargs):
    """Voxel-wise mean of the probability volumes of several models."""
    total = None
    for n, model in enumerate(models):
        print(f"\n--- Model {n + 1}/{len(models)} ---")
        current = predict_salt_prob(model, X, **kwargs)
        total = current if total is None else total + current
        gc.collect()
    return total / len(models)
