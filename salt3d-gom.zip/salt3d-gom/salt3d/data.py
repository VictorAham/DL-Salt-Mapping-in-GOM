"""Volume splitting and the 3D patch generator.

The generator logic is unchanged from the version used for the reported runs.
Note on sample weights: ``DataGenerator.__getitem__`` returns
``(X, Y, depth_labels)``. Keras interprets a third element as sample weights; because
the losses return one value per batch, the data term of each batch's training loss is
scaled by the mean depth-bin index (0, 1, 2) of its patches. Compiled metrics (and
therefore model selection) are not weighted. All reported models were trained this
way. Pass ``depth_sample_weights``-free generators (``NoSampleWeights``) to disable it.
"""
import random

import numpy as np
import tensorflow as tf

from . import config as C
from .augmentation import advanced_seismic_augmentation


# ── Train / validation split ─────────────────────────────────────────────────
def split_train_val(X, y, xl_split=C.XL_SPLIT, buffer_xl=C.BUFFER_XL):
    """Split along the crossline axis (axis 1) with a buffer on each side.

    Training   : crosslines 0 … xl_split - buffer_xl - 1
    Buffer     : crosslines xl_split - buffer_xl … xl_split + buffer_xl - 1 (discarded)
    Validation : crosslines xl_split + buffer_xl … end
    In addition, the training generator excludes patches whose footprint reaches
    into the last 2 x 128 crosslines before the buffer (see DataGenerator).
    """
    train_end = xl_split - buffer_xl
    val_start = xl_split + buffer_xl
    X_train, y_train = X[:, :train_end, :], y[:, :train_end, :]
    X_val, y_val = X[:, val_start:, :], y[:, val_start:, :]
    print(f"Full volume      : {X.shape}")
    print(f"Train region     : crosslines 0–{train_end - 1} → {X_train.shape}")
    print(f"Buffer (excluded): crosslines {train_end}–{val_start - 1} ({2 * buffer_xl} crosslines)")
    print(f"Val region       : crosslines {val_start}–{X.shape[1] - 1} → {X_val.shape}")
    return X_train, y_train, X_val, y_val, val_start


# ── Patch generator ──────────────────────────────────────────────────────────
class DataGenerator(tf.keras.utils.Sequence):
    """NaN-safe 3D patch generator with foreground-ratio and depth-bin balancing.

    The patch pool is built once at initialisation; only the order changes
    between epochs. Patches are (inline, crossline, depth) = patch_size.
    """

    def __init__(self, data, mask,
                 patch_size=C.PATCH_SIZE,
                 threshold=0.1, max_threshold=0.99,
                 low_fg_max=0.50, low_fg_ratio=0.75,
                 bg_ratio=0.15,
                 shallow_max_ft=C.SHALLOW_MAX_FT, mid_max_ft=C.MID_MAX_FT,
                 batch_size=2, stride=96, max_patches=1000,
                 shuffle=True, augment=False, seed=42,
                 depth_stratified=True,
                 max_depth_ft=C.MAX_DEPTH_FT,
                 il_exclude_start=None,
                 il_exclude_end=None,
                 **kwargs):
        super().__init__(**kwargs)
        self.data = data
        self.mask = mask
        self.patch_size = patch_size
        self.threshold = threshold
        self.max_threshold = max_threshold
        self.low_fg_max = low_fg_max
        self.low_fg_ratio = low_fg_ratio
        self.bg_ratio = bg_ratio
        self.shallow_max_ft = shallow_max_ft
        self.mid_max_ft = mid_max_ft
        self.sample_int_ft = C.DZ_FT
        self.batch_size = batch_size
        self.stride = stride
        self.max_patches = max_patches
        self.shuffle = shuffle
        self.augment = augment
        self.seed = seed
        self.depth_stratified = depth_stratified
        self.max_depth_ft = max_depth_ft
        self.il_exclude_start = il_exclude_start
        self.il_exclude_end = il_exclude_end
        self._set_seeds()
        self.indices = self._compute_patch_indices()
        if self.shuffle:
            np.random.shuffle(self.indices)

    def _set_seeds(self):
        np.random.seed(self.seed)
        random.seed(self.seed)
        tf.random.set_seed(self.seed)

    def _is_buffer_adjacent(self, il_s):
        """True if the patch's crossline footprint overlaps the near-buffer exclusion zone."""
        il_end = il_s + self.patch_size[1]
        if self.il_exclude_end is not None and il_s < self.il_exclude_end:
            if il_end > self.il_exclude_end - self.patch_size[1]:
                return True
        if self.il_exclude_start is not None and il_end > self.il_exclude_start:
            if il_s < self.il_exclude_start + self.patch_size[1]:
                return True
        return False

    def depth_bin(self, centre_ft):
        return 0 if centre_ft < self.shallow_max_ft else 1 if centre_ft < self.mid_max_ft else 2

    def _compute_patch_indices(self):
        n0, n1, n2 = self.data.shape
        p0, p1, p2 = self.patch_size
        total_ft = n2 * self.sample_int_ft

        cap_ft = self.max_depth_ft if self.max_depth_ft is not None else total_ft
        if self.max_depth_ft is not None:
            print(f"  Depth cap: {self.max_depth_ft:,.0f} ft "
                  f"(≈ {int(self.max_depth_ft / self.sample_int_ft)} depth samples out of {n2})")

        bins_ft = [(0, self.shallow_max_ft),
                   (self.shallow_max_ft, self.mid_max_ft),
                   (self.mid_max_ft, cap_ft)]
        bg = {b: [] for b in range(3)}        # fg < threshold
        low_fg = {b: [] for b in range(3)}    # threshold <= fg <= low_fg_max
        high_fg = {b: [] for b in range(3)}   # low_fg_max < fg <= max_threshold
        excluded_buffer = excluded_depth = 0

        for i in range(0, n0 - p0 + 1, self.stride):
            for j in range(0, n1 - p1 + 1, self.stride):
                if self._is_buffer_adjacent(j):
                    excluded_buffer += 1
                    continue
                for k in range(0, n2 - p2 + 1, self.stride):
                    cft = (k + p2 // 2) * self.sample_int_ft
                    if cft >= cap_ft:
                        excluded_depth += 1
                        continue
                    dp = self.data[i:i + p0, j:j + p1, k:k + p2]
                    mp = self.mask[i:i + p0, j:j + p1, k:k + p2]
                    if np.isnan(dp).any() or np.isnan(mp).any():
                        continue
                    fg = np.mean(mp)
                    db = next((b for b, (z0, z1) in enumerate(bins_ft) if z0 <= cft < z1), None)
                    if db is None:
                        continue
                    if fg < self.threshold:
                        bg[db].append((i, j, k))
                    elif self.threshold <= fg <= self.low_fg_max:
                        low_fg[db].append((i, j, k))
                    elif self.low_fg_max < fg <= self.max_threshold:
                        high_fg[db].append((i, j, k))
                    # fg > max_threshold: discarded (no boundary information)

        if excluded_buffer:
            print(f"  Buffer exclusion: {excluded_buffer} patch columns dropped")
        if excluded_depth:
            print(f"  Depth exclusion:  {excluded_depth} patches dropped (centre depth ≥ {cap_ft:,.0f} ft)")

        bin_w = C.DEPTH_WEIGHTS_STRATIFIED if self.depth_stratified else C.DEPTH_WEIGHTS_UNIFORM
        state = np.random.get_state()
        np.random.seed(self.seed)
        all_idx = []
        for b in range(3):
            n_bin = int(self.max_patches * bin_w[b])
            n_bg = int(self.bg_ratio * n_bin)
            n_fg = n_bin - n_bg
            n_low = int(self.low_fg_ratio * n_fg)
            n_high = n_fg - n_low
            for pool, n in ((bg[b], n_bg), (low_fg[b], n_low), (high_fg[b], n_high)):
                arr = np.array(pool)
                if len(arr) > 0:
                    all_idx.append(arr[np.random.choice(len(arr), min(n, len(arr)), replace=False)])
        np.random.set_state(state)

        result = np.concatenate(all_idx, axis=0) if all_idx else np.empty((0, 3), dtype=int)
        print(f"  Candidate patches — bg: {sum(len(bg[b]) for b in range(3))}  "
              f"low-fg: {sum(len(low_fg[b]) for b in range(3))}  "
              f"high-fg: {sum(len(high_fg[b]) for b in range(3))}")
        print(f"  Patches selected: {len(result)}  (depth_stratified={self.depth_stratified}, "
              f"bg_ratio={self.bg_ratio}, max_depth_ft={self.max_depth_ft}, seed={self.seed})")
        return result

    def on_epoch_end(self):
        if self.shuffle:
            np.random.shuffle(self.indices)

    def __len__(self):
        return max(1, int(np.floor(len(self.indices) / self.batch_size)))

    def __getitem__(self, index):
        batch = self.indices[index * self.batch_size:(index + 1) * self.batch_size]
        X = np.zeros((len(batch), *self.patch_size, 1), dtype=np.float32)
        Y = np.zeros((len(batch), *self.patch_size, 1), dtype=np.float32)
        depth_labels = []
        for n, (i, j, k) in enumerate(batch):
            xp = self.data[i:i + self.patch_size[0], j:j + self.patch_size[1], k:k + self.patch_size[2]]
            yp = self.mask[i:i + self.patch_size[0], j:j + self.patch_size[1], k:k + self.patch_size[2]]
            if self.augment:
                xp, yp = advanced_seismic_augmentation(xp, yp)
            X[n, ..., 0] = xp
            Y[n, ..., 0] = yp
            depth_labels.append(self.depth_bin((k + self.patch_size[2] // 2) * self.sample_int_ft))
        return X, Y, depth_labels


# ── Wrappers ─────────────────────────────────────────────────────────────────
class DepthWeightedGeneratorWrapper(tf.keras.utils.Sequence):
    """Configurations F and G: append the depth-bin weight as channel 1 of Y.
    Applied to the training generator only; validation stays unwrapped."""

    def __init__(self, generator, bin_weights=None):
        super().__init__()
        self.generator = generator
        self.bin_weights = bin_weights or C.DEPTH_BIN_WEIGHTS

    def __len__(self):
        return len(self.generator)

    def on_epoch_end(self):
        self.generator.on_epoch_end()

    @property
    def indices(self):
        return self.generator.indices

    @property
    def batch_size(self):
        return self.generator.batch_size

    def __getitem__(self, index):
        X, Y, depth_labels = self.generator[index]
        B, D, H, W, _ = Y.shape
        W_vol = np.ones((B, D, H, W, 1), dtype=np.float32)
        for n, d in enumerate(depth_labels):
            W_vol[n] = float(self.bin_weights.get(int(d), 1.0))
        return X, np.concatenate([Y, W_vol], axis=-1), depth_labels


class NoSampleWeights(tf.keras.utils.Sequence):
    """Return (X, Y) only, so that depth-bin labels are NOT used as sample weights.
    Not used for the reported results; provided for corrected re-runs."""

    def __init__(self, generator):
        super().__init__()
        self.generator = generator

    def __len__(self):
        return len(self.generator)

    def on_epoch_end(self):
        self.generator.on_epoch_end()

    @property
    def indices(self):
        return self.generator.indices

    @property
    def batch_size(self):
        return self.generator.batch_size

    def __getitem__(self, index):
        X, Y, _ = self.generator[index]
        return X, Y


def drop_sample_weights(gen):
    """Python-generator equivalent of NoSampleWeights (for perturbation generators)."""
    for X, Y, _ in gen:
        yield X, Y


# ── Builders ─────────────────────────────────────────────────────────────────
def build_generators(X_tr, y_tr, X_vl, y_vl, train_seed=42, val_seed=C.VAL_SEED,
                     depth_stratified=True, patch_size=C.PATCH_SIZE,
                     max_depth_ft=C.MAX_DEPTH_FT):
    """Training and validation generators exactly as used for the reported runs.

    Training patches whose crossline footprint reaches into the last 2 x 128
    crosslines before the buffer are excluded; on the validation side the
    exclusion starts after the first validation patch column.
    """
    tr = DataGenerator(X_tr, y_tr, patch_size=patch_size, seed=train_seed,
                       depth_stratified=depth_stratified, max_depth_ft=max_depth_ft,
                       il_exclude_start=None, il_exclude_end=X_tr.shape[1] - patch_size[1],
                       **C.TRAIN_GENERATOR)
    vl = DataGenerator(X_vl, y_vl, patch_size=patch_size, seed=val_seed,
                       max_depth_ft=max_depth_ft,
                       il_exclude_start=patch_size[1], il_exclude_end=None,
                       **C.VAL_GENERATOR)
    return tr, vl
