"""Extraction of a 3D salt geobody from a probability volume (visualisation only),
with steps adapted from Wu (2016).

These steps are not part of the quantitative evaluation: all reported metrics
are computed on raw probabilities.
"""
import numpy as np
from scipy import ndimage as ndi
from skimage import measure, morphology

from . import config as C


def crop_box(prob, threshold=0.5, pad=20):
    """Bounding box of voxels with prob >= threshold, padded by ``pad`` on the two
    horizontal axes; the depth axis is kept whole (as in the original workflow)."""
    coords = np.argwhere(prob >= threshold)
    if coords.size == 0:
        return None
    a0, b0, _ = coords.min(axis=0)
    a1, b1, _ = coords.max(axis=0) + 1
    return (slice(max(0, a0 - pad), min(prob.shape[0], a1 + pad)),
            slice(max(0, b0 - pad), min(prob.shape[1], b1 + pad)),
            slice(0, prob.shape[2]))


def extract_geobody(prob, sigma=1.2, core_threshold=0.65, shell_threshold=0.45,
                    closing_radius=2, min_component_voxels=800_000,
                    crop_threshold=0.5, crop_pad=20):
    """Binary salt geobody:
    Gaussian smoothing (sigma, voxels) → core (>= core_threshold) and candidate body
    (>= shell_threshold) → closing of the candidate body with a ball of radius
    ``closing_radius`` → hole filling → union with the core → removal of connected
    components smaller than ``min_component_voxels``.
    Processing is done inside the salt bounding box and returned at full size.
    """
    out = np.zeros(prob.shape, dtype=bool)
    box = crop_box(prob, crop_threshold, crop_pad)
    if box is None:
        return out
    prob_s = ndi.gaussian_filter(np.asarray(prob[box], dtype=np.float32), sigma=sigma)
    core = prob_s >= core_threshold
    shell = prob_s >= shell_threshold
    del prob_s
    shell = ndi.binary_closing(shell, structure=morphology.ball(closing_radius))
    shell = ndi.binary_fill_holes(shell)
    shell |= core
    labels, nlab = ndi.label(shell)
    sizes = ndi.sum(shell, labels, range(nlab + 1))
    keep = sizes >= min_component_voxels
    keep[0] = False
    out[box] = keep[labels]
    return out


def extract_surface(geobody, level=0.5, spacing=(1.0, 1.0, 1.0)):
    """Triangulated salt surface (vertices, faces, normals) by marching cubes."""
    verts, faces, normals, _ = measure.marching_cubes(geobody.astype(np.float32), level=level,
                                                      spacing=spacing)
    return verts, faces, normals
