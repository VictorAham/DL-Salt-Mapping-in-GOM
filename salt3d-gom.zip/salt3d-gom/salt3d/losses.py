"""Loss functions and training metrics.

Mathematically identical to the notebook versions; keras.backend shortcuts have
been replaced by the equivalent tf operations so the code runs on TF 2.10-2.18.

Known property of the implementation (reported in the manuscript):
``get_boundary_mask`` thresholds its input, so ``boundary_dice_loss`` applied to
predictions has no gradient with respect to the network output. The boundary-
Dice term therefore does not contribute to training; it is kept unchanged here
so that the reported experiments can be reproduced.
"""
import tensorflow as tf

from . import config as C

EPS = 1e-7  # tf.keras.backend.epsilon()


def _flat(x):
    return tf.reshape(x, [-1])


# ── Region terms ─────────────────────────────────────────────────────────────
def soft_dice_coef(y_true, y_pred, smooth=1e-6):
    yt, yp = _flat(y_true), _flat(y_pred)
    return (2.0 * tf.reduce_sum(yt * yp) + smooth) / (
        tf.reduce_sum(tf.square(yt)) + tf.reduce_sum(tf.square(yp)) + smooth)


def soft_dice_loss(y_true, y_pred):
    return 1.0 - soft_dice_coef(y_true, y_pred)


def balanced_cross_entropy(y_true, y_pred):
    """Class-balanced BCE with per-batch beta = N_neg / (N_neg + N_pos);
    effective weights are beta for salt and (1 - beta) for background."""
    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.clip_by_value(y_pred, EPS, 1.0 - EPS)
    n_pos = tf.maximum(tf.reduce_sum(y_true), 1.0)
    n_neg = tf.maximum(tf.reduce_sum(1.0 - y_true), 1.0)
    beta = n_neg / (n_neg + n_pos)
    pw = beta / (1.0 - beta + EPS)
    logits = tf.math.log(y_pred / (1.0 - y_pred))
    cost = tf.nn.weighted_cross_entropy_with_logits(logits=logits, labels=y_true, pos_weight=pw)
    return tf.where(n_pos < EPS, 0.0, tf.reduce_mean(cost * (1.0 - beta)))


# ── Boundary terms ───────────────────────────────────────────────────────────
def get_boundary_mask(y, boundary_width=C.BOUNDARY_WIDTH):
    """{0,1} band immediately OUTSIDE the salt: (2w+1)^3 dilation minus the mask.
    The input is thresholded at 0.5 (no gradient flows through this function)."""
    if y.shape.rank == 4:
        y = tf.expand_dims(y, -1)
    y_bin = tf.cast(y > 0.5, tf.float32)
    k = 2 * boundary_width + 1
    kernel = tf.ones((k, k, k, 1, 1), dtype=tf.float32)
    dilated = tf.nn.conv3d(y_bin, kernel, strides=[1, 1, 1, 1, 1], padding="SAME")
    return tf.clip_by_value(tf.cast(dilated > 0.5, tf.float32) - y_bin, 0.0, 1.0)


def boundary_dice_loss(y_true, y_pred, boundary_width=C.BOUNDARY_WIDTH, smooth=1e-6):
    """Dice between the boundary bands of reference and prediction (alpha_3 term)."""
    bt = _flat(get_boundary_mask(y_true, boundary_width))
    bp = _flat(get_boundary_mask(y_pred, boundary_width))
    return 1.0 - (2.0 * tf.reduce_sum(bt * bp) + smooth) / (
        tf.reduce_sum(tf.square(bt)) + tf.reduce_sum(tf.square(bp)) + smooth)


def distance_weighted_bce(y_true, y_pred, boundary_width=C.BOUNDARY_WIDTH):
    """BCE weighted by (1 + d_j), d_j = 1 inside the boundary band (alpha_4 term).
    Not class-balanced."""
    weights = 1.0 + get_boundary_mask(y_true, boundary_width)
    bce = tf.keras.losses.binary_crossentropy(y_true, y_pred)
    if bce.shape.rank == 4:
        bce = tf.expand_dims(bce, -1)
    return tf.reduce_mean(bce * weights)


# ── Composite losses ─────────────────────────────────────────────────────────
def salt_ultimate_loss(y_true, y_pred, dice_weight=0.2, bce_weight=0.2,
                       boundary_weight=0.6, boundary_width=C.BOUNDARY_WIDTH):
    """Four-term composite loss (alpha = 0.2, 0.2, 0.3, 0.3). Configurations D, E,
    the base model and the perturbation models."""
    return (dice_weight * soft_dice_loss(y_true, y_pred)
            + bce_weight * balanced_cross_entropy(y_true, y_pred)
            + 0.5 * boundary_weight * boundary_dice_loss(y_true, y_pred, boundary_width)
            + 0.5 * boundary_weight * distance_weighted_bce(y_true, y_pred, boundary_width))


def simple_dice_bce_loss(y_true, y_pred):
    """Dice + balanced BCE baseline (0.5 each). Configurations A-C."""
    return 0.5 * soft_dice_loss(y_true, y_pred) + 0.5 * balanced_cross_entropy(y_true, y_pred)


def salt_ultimate_loss_depth_weighted(y_true_aug, y_pred):
    """Depth-bin-weighted composite loss used for Configurations F and G (as run).

    y_true_aug: (B, D, H, W, 2) during training (channel 1 = depth-bin weight),
                (B, D, H, W, 1) during validation (weight defaults to 1).
    As implemented, this loss differs from salt_ultimate_loss in three ways:
    per-sample depth-bin weighting, term weights 0.35/0.25/0.20/0.20, and a
    10-voxel boundary band.
    """
    smooth = 1e-6
    w = C.DEPTH_WEIGHTED_LOSS_WEIGHTS
    y_true = y_true_aug[..., 0:1]
    # Per-sample weight: channel 1 when present (training), otherwise 1.0 (validation).
    # Appending a channel of ones and reading channel 1 is equivalent to the original
    # tf.cond formulation and avoids shape errors when Y has a single channel.
    padded = tf.concat([y_true_aug, tf.ones_like(y_true_aug[..., 0:1])], axis=-1)
    w_per = tf.cast(padded[:, 0, 0, 0, 1], tf.float32)

    batch = tf.shape(y_true)[0]
    yt_flat = tf.reshape(y_true, [batch, -1])
    yp_flat = tf.reshape(y_pred, [batch, -1])
    dice_per = 1.0 - (2.0 * tf.reduce_sum(yt_flat * yp_flat, axis=1) + smooth) / (
        tf.reduce_sum(tf.square(yt_flat), axis=1) + tf.reduce_sum(tf.square(yp_flat), axis=1) + smooth)

    yp_c = tf.clip_by_value(y_pred, EPS, 1.0 - EPS)
    n_pos = tf.maximum(tf.reduce_sum(y_true, axis=[1, 2, 3, 4]), 1.0)
    n_neg = tf.maximum(tf.reduce_sum(1.0 - y_true, axis=[1, 2, 3, 4]), 1.0)
    b5 = tf.reshape(n_neg / (n_neg + n_pos), [-1, 1, 1, 1, 1])
    bce_per = tf.reduce_mean(-(b5 * y_true * tf.math.log(yp_c)
                               + (1.0 - b5) * (1.0 - y_true) * tf.math.log(1.0 - yp_c)),
                             axis=[1, 2, 3, 4])

    bw = C.DEPTH_WEIGHTED_BOUNDARY_WIDTH
    k = 2 * bw + 1
    kernel = tf.ones((k, k, k, 1, 1), dtype=tf.float32)
    yt_bin = tf.cast(y_true > 0.5, tf.float32)
    bt = tf.clip_by_value(tf.cast(tf.nn.conv3d(yt_bin, kernel, [1, 1, 1, 1, 1], "SAME") > 0.5,
                                  tf.float32) - yt_bin, 0.0, 1.0)
    yp_bin = tf.cast(y_pred > 0.5, tf.float32)
    bp = tf.clip_by_value(tf.cast(tf.nn.conv3d(yp_bin, kernel, [1, 1, 1, 1, 1], "SAME") > 0.5,
                                  tf.float32) - yp_bin, 0.0, 1.0)
    bt_flat = tf.reshape(bt, [batch, -1])
    bp_flat = tf.reshape(bp, [batch, -1])
    bdice_per = 1.0 - (2.0 * tf.reduce_sum(bt_flat * bp_flat, axis=1) + smooth) / (
        tf.reduce_sum(tf.square(bt_flat), axis=1) + tf.reduce_sum(tf.square(bp_flat), axis=1) + smooth)

    bce2 = tf.expand_dims(tf.keras.losses.binary_crossentropy(y_true, y_pred), -1)
    dwbce_per = tf.reduce_mean(bce2 * (1.0 + bt), axis=[1, 2, 3, 4])

    loss_per = (w["dice"] * dice_per + w["bce"] * bce_per
                + w["boundary_dice"] * bdice_per + w["distance_bce"] * dwbce_per)
    return tf.reduce_mean(loss_per * w_per)


# ── Metrics ──────────────────────────────────────────────────────────────────
def boundary_iou(y_true, y_pred):
    """IoU of the 3-voxel boundary bands of reference and binarized prediction."""
    bt = get_boundary_mask(y_true)
    bp = get_boundary_mask(y_pred)
    inter = tf.reduce_sum(bt * bp)
    union = tf.reduce_sum(bt) + tf.reduce_sum(bp) - inter
    return (inter + 1e-6) / (union + 1e-6)


def mean_iou(y_true, y_pred):
    """IoU of the salt class at threshold 0.5 (reported as 'mean IoU')."""
    yt = tf.cast(y_true, tf.float32)
    yp = tf.cast(y_pred > 0.5, tf.float32)
    inter = tf.reduce_sum(yt * yp)
    union = tf.reduce_sum(yt) + tf.reduce_sum(yp) - inter
    return (inter + 1e-6) / (union + 1e-6)


METRICS = [soft_dice_coef, mean_iou, boundary_iou, distance_weighted_bce, boundary_dice_loss]


# Channel-safe wrappers for Configurations F and G (Y may carry a weight channel)
def soft_dice_coef_f(y, yp):        return soft_dice_coef(y[..., 0:1], yp)
def mean_iou_f(y, yp):              return mean_iou(y[..., 0:1], yp)
def boundary_iou_f(y, yp):          return boundary_iou(y[..., 0:1], yp)
def distance_weighted_bce_f(y, yp): return distance_weighted_bce(y[..., 0:1], yp)
def boundary_dice_loss_f(y, yp):    return boundary_dice_loss(y[..., 0:1], yp)


METRICS_F = [soft_dice_coef_f, mean_iou_f, boundary_iou_f, distance_weighted_bce_f, boundary_dice_loss_f]

CUSTOM_OBJECTS = {f.__name__: f for f in METRICS + METRICS_F + [
    soft_dice_loss, balanced_cross_entropy, salt_ultimate_loss, simple_dice_bce_loss,
    salt_ultimate_loss_depth_weighted]}
