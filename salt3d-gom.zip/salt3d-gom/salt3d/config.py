"""Central configuration.

Every value in this file is the one used to produce the results reported in the
manuscript (Tables 3-5). Change values here, not inside the modules, so that a
run can always be traced back to one configuration.
"""

# ── Data and grid ────────────────────────────────────────────────────────────
H5_KEY = "cube"                 # dataset name inside seismic.h5 / salt.h5
DZ_FT = 32.0                    # vertical sample interval (ft)
PATCH_SIZE = (128, 128, 128)    # (inline, crossline, depth) voxels

# Train/validation split along the crossline axis (axis 1 of the volume)
XL_SPLIT = 1100                 # nominal boundary crossline index
BUFFER_XL = 5                   # crosslines removed on EACH side of the split

# Depth handling (feet)
MAX_DEPTH_FT = 40000            # patches whose centre is deeper are excluded
SHALLOW_MAX_FT = 15000          # D0 / D1 boundary
MID_MAX_FT = 25000              # D1 / D2 boundary

# ── Patch sampling (DataGenerator) ───────────────────────────────────────────
# Background patches: salt fraction < threshold; low-foreground: threshold to
# low_fg_max; high-foreground: low_fg_max to max_threshold; above it discarded.
TRAIN_GENERATOR = dict(
    batch_size=4, threshold=0.1, low_fg_max=0.30, max_threshold=0.8,
    low_fg_ratio=0.75, stride=64, max_patches=1000, bg_ratio=0.15,
    shuffle=True, augment=True,
)
VAL_GENERATOR = dict(
    batch_size=4, threshold=0.1, low_fg_max=0.30, max_threshold=0.8,
    low_fg_ratio=0.5, stride=64,            # stride 64 = setting used in all reported runs
    max_patches=100, bg_ratio=0.15,
    shuffle=False, augment=False, depth_stratified=False,
)
DEPTH_WEIGHTS_STRATIFIED = (0.10, 0.45, 0.45)   # D0, D1, D2 share of the patch budget
DEPTH_WEIGHTS_UNIFORM = (0.33, 0.34, 0.33)

# ── Seeds ────────────────────────────────────────────────────────────────────
TRAIN_SEEDS = (42, 123, 7)      # training-generator seeds (ablation)
VAL_SEED = 999                  # validation generator, fixed for every run
BASE_SEED = 42                  # base model (= Configuration E, seed 42)

# ── Optimisation ─────────────────────────────────────────────────────────────
EPOCHS = 75
LEARNING_RATE = 1e-4
L2_REG = 1e-4
EARLY_STOP_PATIENCE = 10        # epochs without improvement in val soft Dice
LR_FACTOR = 0.5
LR_PATIENCE = 5
MIN_LR = 1e-7

# ── Architecture ─────────────────────────────────────────────────────────────
ABLATION_BASE_FILTERS = 7       # filters [7, 14, 28, 56, 112]
SE_REDUCTION = 8
BRIDGE_DROPOUT = 0.3            # SpatialDropout3D after the residual bridge

# ── Losses ───────────────────────────────────────────────────────────────────
COMPOSITE_WEIGHTS = dict(dice=0.2, bce=0.2, boundary_dice=0.3, distance_bce=0.3)
BOUNDARY_WIDTH = 3              # voxels; band = 7x7x7 dilation minus the mask
# Configurations F and G (depth-bin-weighted composite loss). As run, this loss
# also uses different term weights and a 10-voxel boundary band.
DEPTH_BIN_WEIGHTS = {0: 0.3333, 1: 2.0000, 2: 0.6667}
DEPTH_WEIGHTED_LOSS_WEIGHTS = dict(dice=0.35, bce=0.25, boundary_dice=0.20, distance_bce=0.20)
DEPTH_WEIGHTED_BOUNDARY_WIDTH = 10

# ── Perturbation fine-tuning (initialised from the base model) ───────────────
PERTURBATION = {
    "seismic": dict(seismic_prob=0.75, label_prob=None),
    "label":   dict(seismic_prob=None, label_prob=0.50),
    "joint":   dict(seismic_prob=0.50, label_prob=0.50),   # label first, then seismic
}
LABEL_DEPTH_PROBS = {0: 0.20, 1: 0.40, 2: 0.60}            # scaled by label_prob / 0.5

# ── Inference and postprocessing ─────────────────────────────────────────────
THRESHOLD = 0.50
INFERENCE = dict(patch_size=PATCH_SIZE, stride=64, batch_size=4, max_depth_ft=40000)
POSTPROCESS = dict(sigma=1.2, core_threshold=0.65, shell_threshold=0.45,
                   closing_radius=2, min_component_voxels=800_000,
                   crop_threshold=0.5, crop_pad=20)

# ── Evaluation ───────────────────────────────────────────────────────────────
EVAL_BOUNDARY_WIDTH = 2         # boundary band (voxels) for numpy boundary IoU
