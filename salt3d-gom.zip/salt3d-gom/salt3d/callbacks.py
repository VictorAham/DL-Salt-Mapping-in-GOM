"""Training callbacks: early stopping, learning-rate schedule, checkpoints and
per-depth-bin validation metrics."""
import os
from collections import defaultdict

import numpy as np
import tensorflow as tf
from scipy.ndimage import binary_dilation

from . import config as C


def numpy_boundary_mask(y, bw=2):
    y_bin = (y > 0.5).astype(np.float32)
    dilated = binary_dilation(y_bin, structure=np.ones((2 * bw + 1,) * 3)).astype(np.float32)
    return np.clip(dilated - y_bin, 0.0, 1.0)


def numpy_boundary_iou(y_true, y_pred_bin, bw=2):
    bt, bp = numpy_boundary_mask(y_true, bw), numpy_boundary_mask(y_pred_bin, bw)
    inter = np.sum(bt * bp)
    union = np.sum(bt) + np.sum(bp) - inter
    return (inter + 1e-6) / (union + 1e-6)


class DepthStratifiedMetrics(tf.keras.callbacks.Callback):
    """Logs per-epoch soft Dice and boundary IoU for each depth bin (D0/D1/D2),
    computed per validation patch and averaged within each bin."""

    def __init__(self, val_gen, boundary_width=2):
        super().__init__()
        self.val_gen = val_gen
        self.boundary_width = boundary_width
        self.dice_history = {"0": [], "1": [], "2": []}
        self.biou_history = {"0": [], "1": [], "2": []}

    def on_epoch_end(self, epoch, logs=None):
        by_depth = defaultdict(lambda: {"soft_dice": [], "b_iou": []})
        for i in range(len(self.val_gen)):
            try:
                Xv, yt, depths = self.val_gen[i]
                yp_raw = self.model.predict(Xv, verbose=0)
                yp_bin = (yp_raw > 0.5).astype(np.float32)
                for j in range(len(Xv)):
                    d = str(depths[j])
                    yt_, yps, ypb = np.squeeze(yt[j]), np.squeeze(yp_raw[j]), np.squeeze(yp_bin[j])
                    sd = (2 * np.sum(yt_ * yps) + 1e-6) / (np.sum(np.square(yt_)) + np.sum(np.square(yps)) + 1e-6)
                    by_depth[d]["soft_dice"].append(sd)
                    by_depth[d]["b_iou"].append(numpy_boundary_iou(yt_, ypb, self.boundary_width))
            except Exception:
                continue
        for d in ["0", "1", "2"]:
            if by_depth.get(d, {}).get("soft_dice"):
                self.dice_history[d].append(float(np.mean(by_depth[d]["soft_dice"])))
                self.biou_history[d].append(float(np.mean(by_depth[d]["b_iou"])))
        all_d = [v for vals in by_depth.values() for v in vals["soft_dice"]]
        if all_d:
            all_b = [v for vals in by_depth.values() for v in vals["b_iou"]]
            print(f"\n  [Depth] Epoch {epoch + 1} | Dice={np.mean(all_d):.4f} | bIoU={np.mean(all_b):.4f}")
            for dep in sorted(by_depth):
                v = by_depth[dep]
                print(f"    D{dep}: Dice={np.mean(v['soft_dice']):.4f}±{np.std(v['soft_dice']):.3f}"
                      f"  bIoU={np.mean(v['b_iou']):.4f}  ({len(v['soft_dice'])} patches)")

    def as_dict(self):
        return {"soft_dice": self.dice_history, "boundary_iou": self.biou_history}


def _schedule(monitor):
    return [
        tf.keras.callbacks.EarlyStopping(monitor=monitor, mode="max", patience=C.EARLY_STOP_PATIENCE,
                                         restore_best_weights=True, verbose=1),
        tf.keras.callbacks.ReduceLROnPlateau(monitor=monitor, mode="max", factor=C.LR_FACTOR,
                                             patience=C.LR_PATIENCE, min_lr=C.MIN_LR, verbose=1),
    ]


def ablation_callbacks(run_dir, val_gen, depth_weighted=False):
    """Ablation runs: checkpoint best.h5 on validation soft Dice.
    Configurations F and G monitor the channel-safe metric and log depth bins with a 3-voxel band."""
    monitor = "val_soft_dice_coef_f" if depth_weighted else "val_soft_dice_coef"
    os.makedirs(run_dir, exist_ok=True)
    depth_cb = DepthStratifiedMetrics(val_gen, boundary_width=3 if depth_weighted else 2)
    cbs = _schedule(monitor) + [
        tf.keras.callbacks.ModelCheckpoint(os.path.join(run_dir, "best.h5"), monitor=monitor,
                                           save_best_only=True, mode="max", verbose=1),
        tf.keras.callbacks.CSVLogger(os.path.join(run_dir, "training_log.csv")),
        depth_cb,
    ]
    return cbs, depth_cb


def perturbation_callbacks(out_dir, name, val_gen):
    """Base and perturbation runs: checkpoints on validation boundary IoU and soft Dice.
    Reported results use <name>_best_dice.h5."""
    os.makedirs(out_dir, exist_ok=True)
    depth_cb = DepthStratifiedMetrics(val_gen, boundary_width=2)
    cbs = [
        tf.keras.callbacks.ModelCheckpoint(os.path.join(out_dir, f"{name}_best_biou.h5"),
                                           monitor="val_boundary_iou", save_best_only=True,
                                           mode="max", verbose=1),
        tf.keras.callbacks.ModelCheckpoint(os.path.join(out_dir, f"{name}_best_dice.h5"),
                                           monitor="val_soft_dice_coef", save_best_only=True,
                                           mode="max", verbose=1),
        tf.keras.callbacks.CSVLogger(os.path.join(out_dir, f"{name}_training_log.csv")),
    ] + _schedule("val_soft_dice_coef") + [depth_cb]
    return cbs, depth_cb


def best_epoch_metrics(history, depth_weighted=False):
    """All metrics read from the SAME epoch: the one with the highest validation soft Dice."""
    sfx = "_f" if depth_weighted else ""
    h = history.history
    ep = int(np.argmax(h[f"val_soft_dice_coef{sfx}"]))
    return dict(best_epoch=ep + 1,
                dice=float(h[f"val_soft_dice_coef{sfx}"][ep]),
                mean_iou=float(h[f"val_mean_iou{sfx}"][ep]),
                boundary_iou=float(h[f"val_boundary_iou{sfx}"][ep]))
