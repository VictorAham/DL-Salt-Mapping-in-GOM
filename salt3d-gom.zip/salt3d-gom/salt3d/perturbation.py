"""Seismic and label perturbation used to fine-tune the base model.

Both are infinite Python generators that wrap a DataGenerator and yield
(X, Y, depth_labels) batches, exactly as used for the reported runs.
"""
import numpy as np
import tensorflow as tf
from scipy.ndimage import binary_dilation, binary_erosion, gaussian_filter

from . import config as C


def seismic_perturbation_gen(data_gen, perturbation_prob=0.75):
    """Perturb shallow (D0) patches only, each with probability ``perturbation_prob``.

    Applied to selected patches, in order:
      1. gain: multiply by U[0.2, 2.0] (per patch);
      2. additive Gaussian noise with std = U[0.15, 0.40] x the std of the gained BATCH;
      3. sinusoidal artefact, amplitude U[0.05, 0.15], phase span U[1, 4]*pi along the
         patch's second axis (crossline), random phase per patch;
      4. 3x3x3 mean filter with probability 0.5;
      5. clipping to [-1.5, 1.5].
    Mid-depth and deep patches pass through unchanged.
    """
    while True:
        for batch_data, batch_mask, depth_labels in data_gen:
            orig = tf.convert_to_tensor(batch_data, dtype=tf.float32)
            bs = tf.shape(orig)[0]
            dl = tf.convert_to_tensor(depth_labels)
            dlabels = tf.squeeze(dl, axis=-1) if len(dl.shape) > 1 else dl
            is_d0 = tf.equal(dlabels, 0)
            pmask = tf.random.uniform([bs, 1, 1, 1, 1]) < perturbation_prob
            fmask = tf.logical_and(is_d0[:, None, None, None, None], pmask)

            aug = orig * tf.random.uniform([bs, 1, 1, 1, 1], 0.2, 2.0)
            std = tf.math.reduce_std(aug)
            ns = tf.random.uniform([bs], 0.15, 0.40) * std
            aug = aug + tf.random.normal(tf.shape(aug), 0.0, ns[:, None, None, None, None])
            s_str = tf.random.uniform([bs, 1, 1, 1, 1], 0.05, 0.15)
            tdim = tf.shape(aug)[1]
            freq = tf.random.uniform([], 1.0, 4.0) * np.pi
            t = tf.linspace(0.0, freq, tdim)
            ph = tf.random.uniform([bs], 0.0, 2 * np.pi)
            aug = aug + s_str * tf.sin(t[None, :, None, None, None] + ph[:, None, None, None, None])
            blurred = tf.nn.conv3d(aug, tf.ones((3, 3, 3, 1, 1)) / 27.0,
                                   strides=[1, 1, 1, 1, 1], padding="SAME")
            aug = tf.where(tf.random.uniform([bs, 1, 1, 1, 1]) < 0.5, blurred, aug)
            aug = tf.clip_by_value(aug, -1.5, 1.5)
            yield tf.where(fmask, aug, orig).numpy(), batch_mask, depth_labels
        data_gen.on_epoch_end()


def label_perturbation_gen(data_gen, perturbation_prob=0.5):
    """Perturb reference masks with depth-dependent probability
    (D0 0.20, D1 0.40, D2 0.60, scaled by perturbation_prob / 0.5).

    Selected masks are blurred with a Gaussian filter (sigma ~ U[1, 2]); with
    probability 0.30 (if the patch is neither empty nor full) the blurred mask is
    re-binarized, eroded or dilated by one iteration (equal probability) and
    smoothed again (sigma = 0.5). Values are clipped to [0, 1].
    """
    depth_probs = C.LABEL_DEPTH_PROBS
    while True:
        for batch_data, batch_mask, depth_labels in data_gen:
            pm = batch_mask.copy().astype(np.float32)
            for i in range(pm.shape[0]):
                d = depth_labels[i] if isinstance(depth_labels, list) else int(depth_labels[i])
                if np.random.rand() < depth_probs.get(d, 0.4) * (perturbation_prob / 0.5):
                    has_ch = pm.ndim == 5
                    ms = pm[i, ..., 0] if has_ch else pm[i]
                    ms = gaussian_filter(ms, sigma=np.random.uniform(1.0, 2.0))
                    if np.random.rand() < 0.30 and 0.01 < np.mean(ms) < 0.99:
                        bm = ms > 0.5
                        bm = (binary_erosion(bm, iterations=1) if np.random.rand() > 0.5
                              else binary_dilation(bm, iterations=1))
                        ms = gaussian_filter(bm.astype(np.float32), sigma=0.5)
                    if has_ch:
                        pm[i, ..., 0] = np.clip(ms, 0, 1)
                    else:
                        pm[i] = np.clip(ms, 0, 1)
            yield batch_data, pm, depth_labels
        if hasattr(data_gen, "on_epoch_end"):
            data_gen.on_epoch_end()
