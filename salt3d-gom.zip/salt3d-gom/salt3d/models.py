"""3D encoder-decoder architectures and the ablation registry.

Trainable parameter counts (input 128^3, base filters 7):
    plain_unet_3d                 1,241,521   (Configuration A)
    resunet_3d(use_se=False)      1,232,743   (Configuration B)
    resunet_3d(use_se=True)       1,240,642   (Configurations C-G, base, perturbed)
"""
import tensorflow as tf
from tensorflow.keras import layers as L

from . import config as C
from .losses import (METRICS, METRICS_F, salt_ultimate_loss, salt_ultimate_loss_depth_weighted,
                     simple_dice_bce_loss)


def _reg(l2_reg):
    return tf.keras.regularizers.l2(l2_reg)


# ── Building blocks ──────────────────────────────────────────────────────────
def conv_bn_relu_3d(x, filters, kernel_size=3, strides=1, l2_reg=C.L2_REG):
    x = L.Conv3D(filters, kernel_size, strides=strides, padding="same", use_bias=False,
                 kernel_initializer="he_normal", kernel_regularizer=_reg(l2_reg))(x)
    x = L.BatchNormalization()(x)
    return L.Activation("relu")(x)


def upsample_conv_bn_relu_3d(x, filters, kernel_size=3, size=(2, 2, 2), l2_reg=C.L2_REG):
    x = L.UpSampling3D(size=size)(x)
    return conv_bn_relu_3d(x, filters, kernel_size=kernel_size, l2_reg=l2_reg)


def se_block_3d(x, reduction=C.SE_REDUCTION):
    """Squeeze-and-Excitation channel recalibration (Hu et al. 2018)."""
    f = x.shape[-1]
    se = L.GlobalAveragePooling3D()(x)
    se = L.Dense(max(1, f // reduction), activation="relu")(se)
    se = L.Dense(f, activation="sigmoid")(se)
    se = L.Reshape((1, 1, 1, f))(se)
    return L.Multiply()([x, se])


def residual_bottleneck_block_3d(x, filters, strides=1, l2_reg=C.L2_REG, use_se=False):
    """1x1 compression, 3x3x3 convolution, 1x1 expansion (expansion factor 1),
    optional SE block, identity or 1x1 projection shortcut."""
    shortcut = x
    x = conv_bn_relu_3d(x, filters, kernel_size=1, strides=strides, l2_reg=l2_reg)
    x = conv_bn_relu_3d(x, filters, kernel_size=3, strides=1, l2_reg=l2_reg)
    x = L.Conv3D(filters, 1, strides=1, padding="same", use_bias=False,
                 kernel_initializer="he_normal", kernel_regularizer=_reg(l2_reg))(x)
    x = L.BatchNormalization()(x)
    if use_se:
        x = se_block_3d(x)
    if shortcut.shape[-1] != filters or strides != 1:
        shortcut = L.Conv3D(filters, 1, strides=strides, padding="same", use_bias=False,
                            kernel_initializer="he_normal", kernel_regularizer=_reg(l2_reg))(shortcut)
        shortcut = L.BatchNormalization()(shortcut)
    return L.Activation("relu")(L.Add()([x, shortcut]))


def make_res_blocks(x, filters, blocks, strides=1, l2_reg=C.L2_REG, use_se=False):
    x = residual_bottleneck_block_3d(x, filters, strides=strides, l2_reg=l2_reg, use_se=use_se)
    for _ in range(1, blocks):
        x = residual_bottleneck_block_3d(x, filters, strides=1, l2_reg=l2_reg, use_se=use_se)
    return x


# ── Configuration A: plain 3D U-Net ──────────────────────────────────────────
def plain_unet_3d(input_shape=C.PATCH_SIZE + (1,), l2_reg=C.L2_REG, lr=C.LEARNING_RATE,
                  compile_model=True):
    B = C.ABLATION_BASE_FILTERS

    def dconv(x, f):
        return conv_bn_relu_3d(conv_bn_relu_3d(x, f, l2_reg=l2_reg), f, l2_reg=l2_reg)

    inp = L.Input(shape=input_shape)
    e1 = dconv(inp, B);     p1 = L.MaxPooling3D(2)(e1)
    e2 = dconv(p1, B * 2);  p2 = L.MaxPooling3D(2)(e2)
    e3 = dconv(p2, B * 4);  p3 = L.MaxPooling3D(2)(e3)
    e4 = dconv(p3, B * 8);  p4 = L.MaxPooling3D(2)(e4)
    b = dconv(p4, B * 16)
    d4 = dconv(L.Concatenate()([upsample_conv_bn_relu_3d(b, B * 8, l2_reg=l2_reg), e4]), B * 8)
    d3 = dconv(L.Concatenate()([upsample_conv_bn_relu_3d(d4, B * 4, l2_reg=l2_reg), e3]), B * 4)
    d2 = dconv(L.Concatenate()([upsample_conv_bn_relu_3d(d3, B * 2, l2_reg=l2_reg), e2]), B * 2)
    d1 = dconv(L.Concatenate()([upsample_conv_bn_relu_3d(d2, B, l2_reg=l2_reg), e1]), B)
    out = L.Conv3D(1, 1, padding="same", activation="sigmoid", dtype="float32")(d1)
    m = tf.keras.Model(inp, out, name="PlainUNet3D")
    if compile_model:
        m.compile(optimizer=tf.keras.optimizers.Adam(lr), loss=simple_dice_bce_loss, metrics=METRICS)
    return m


# ── Configurations B-G: residual encoder-decoder, optional SE ───────────────
def resunet_3d(input_shape=C.PATCH_SIZE + (1,), use_se=False, loss_fn=simple_dice_bce_loss,
               l2_reg=C.L2_REG, lr=C.LEARNING_RATE, compile_model=True):
    B = C.ABLATION_BASE_FILTERS
    inp = L.Input(shape=input_shape)
    e0_pre = conv_bn_relu_3d(inp, B * 2, kernel_size=7, l2_reg=l2_reg)
    e0 = L.MaxPooling3D(pool_size=2, strides=2, padding="same")(e0_pre)

    e1 = make_res_blocks(e0, B, blocks=1, strides=1, l2_reg=l2_reg, use_se=use_se)
    e2 = make_res_blocks(e1, B * 2, blocks=1, strides=2, l2_reg=l2_reg, use_se=use_se)
    e3 = make_res_blocks(e2, B * 4, blocks=1, strides=2, l2_reg=l2_reg, use_se=use_se)
    e4 = make_res_blocks(e3, B * 8, blocks=1, strides=2, l2_reg=l2_reg, use_se=use_se)
    b = make_res_blocks(e4, B * 16, blocks=1, strides=1, l2_reg=l2_reg, use_se=use_se)
    b = L.SpatialDropout3D(C.BRIDGE_DROPOUT)(b)

    d4 = L.Concatenate()([upsample_conv_bn_relu_3d(b, B * 8, l2_reg=l2_reg), e3])
    d4 = make_res_blocks(d4, B * 16, blocks=1, l2_reg=l2_reg, use_se=use_se)
    d3 = L.Concatenate()([upsample_conv_bn_relu_3d(d4, B * 4, l2_reg=l2_reg), e2])
    d3 = make_res_blocks(d3, B * 4, blocks=1, l2_reg=l2_reg, use_se=use_se)
    d2 = L.Concatenate()([upsample_conv_bn_relu_3d(d3, B * 2, l2_reg=l2_reg), e1])
    d2 = make_res_blocks(d2, B * 2, blocks=1, l2_reg=l2_reg, use_se=use_se)
    d1 = L.Concatenate()([upsample_conv_bn_relu_3d(d2, B, l2_reg=l2_reg), e0_pre])
    d1 = make_res_blocks(d1, B, blocks=1, l2_reg=l2_reg, use_se=use_se)
    d1 = conv_bn_relu_3d(d1, B * 4, kernel_size=7, l2_reg=l2_reg)

    out = L.Conv3D(1, 1, padding="same", activation="sigmoid", dtype="float32")(d1)
    m = tf.keras.Model(inp, out, name=("SE-" if use_se else "") + "ResUNet3D")
    if compile_model:
        m.compile(optimizer=tf.keras.optimizers.Adam(lr), loss=loss_fn, metrics=METRICS)
    return m


def build_depth_weighted_model(lr=C.LEARNING_RATE):
    """Configurations F and G: SE-ResUNet compiled with the depth-bin-weighted loss."""
    m = resunet_3d(use_se=True, loss_fn=salt_ultimate_loss, lr=lr)
    m.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=lr),
              loss=salt_ultimate_loss_depth_weighted, metrics=METRICS_F)
    return m


# ── Ablation registry ────────────────────────────────────────────────────────
ABLATION_CONFIGS = {
    "A": dict(label="A: Plain 3D U-Net", depth_stratified=False, depth_weighted=False,
              build=lambda: plain_unet_3d(), arch="plain_unet"),
    "B": dict(label="B: 3D ResUNet (no SE)", depth_stratified=False, depth_weighted=False,
              build=lambda: resunet_3d(use_se=False, loss_fn=simple_dice_bce_loss), arch="resunet"),
    "C": dict(label="C: 3D SE-ResUNet", depth_stratified=False, depth_weighted=False,
              build=lambda: resunet_3d(use_se=True, loss_fn=simple_dice_bce_loss), arch="se_resunet"),
    "D": dict(label="D: SE-ResUNet + composite loss", depth_stratified=False, depth_weighted=False,
              build=lambda: resunet_3d(use_se=True, loss_fn=salt_ultimate_loss), arch="se_resunet"),
    "E": dict(label="E: D + depth-stratified sampling", depth_stratified=True, depth_weighted=False,
              build=lambda: resunet_3d(use_se=True, loss_fn=salt_ultimate_loss), arch="se_resunet"),
    "F": dict(label="F: E + depth-bin-weighted loss", depth_stratified=True, depth_weighted=True,
              build=build_depth_weighted_model, arch="se_resunet"),
    "G": dict(label="G: D + depth-bin-weighted loss", depth_stratified=False, depth_weighted=True,
              build=build_depth_weighted_model, arch="se_resunet"),
}


def build_for_inference(arch):
    """Uncompiled network for prediction: 'plain_unet', 'resunet' or 'se_resunet'."""
    if arch == "plain_unet":
        return plain_unet_3d(compile_model=False)
    if arch == "resunet":
        return resunet_3d(use_se=False, compile_model=False)
    if arch == "se_resunet":
        return resunet_3d(use_se=True, compile_model=False)
    raise ValueError(f"Unknown architecture '{arch}' (use plain_unet, resunet or se_resunet)")
