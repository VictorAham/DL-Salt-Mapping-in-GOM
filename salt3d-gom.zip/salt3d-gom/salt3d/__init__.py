"""salt3d: 3D deep-learning salt-body segmentation for Gulf of Mexico seismic volumes.

Code accompanying Aham, Gani, Singh & Pahari, "Depth-Stratified 3D Deep Learning
with Perturbation Training for Salt-Body Delineation in Gulf of Mexico Seismic Volumes".
"""
__version__ = "1.0.0"
