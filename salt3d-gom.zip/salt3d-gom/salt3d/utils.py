"""General utilities: GPU configuration, seeding, and file I/O."""
import json
import os
import random

import h5py
import numpy as np

from . import config as C


def configure_gpu():
    """Enable memory growth on all GPUs (as in the original notebooks)."""
    os.environ.setdefault("TF_FORCE_GPU_ALLOW_GROWTH", "true")
    os.environ.setdefault("TF_CUDNN_USE_FRONTEND", "0")
    import tensorflow as tf
    gpus = tf.config.experimental.list_physical_devices("GPU")
    for g in gpus:
        try:
            tf.config.experimental.set_memory_growth(g, True)
        except RuntimeError:
            pass
    print(f"GPUs available: {gpus}")
    return gpus


def set_seeds(seed):
    """Seed Python, NumPy and TensorFlow. GPU operations are not made deterministic,
    so repeated runs with the same seed are close but not bit-identical."""
    import tensorflow as tf
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)
    return path


def load_cube(path, key=C.H5_KEY, dtype=np.float32):
    """Load a full 3D volume (inline, crossline, depth) from an HDF5 file."""
    with h5py.File(path, "r") as f:
        return f[key][:].astype(dtype, copy=False)


def save_cube(path, array, key="prob", compression="gzip"):
    ensure_dir(os.path.dirname(os.path.abspath(path)))
    with h5py.File(path, "w") as f:
        f.create_dataset(key, data=array, compression=compression)
    print(f"Saved {key} {array.shape} → {path}")


def save_json(path, obj):
    ensure_dir(os.path.dirname(os.path.abspath(path)))
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, default=float)


def save_history(path, history):
    """Save a Keras History object (all logged metrics per epoch) as JSON."""
    save_json(path, {k: [float(v) for v in vs] for k, vs in history.history.items()})
