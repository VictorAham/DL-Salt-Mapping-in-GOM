# salt3d-gom

Code for **"Depth-Stratified 3D Deep Learning with Perturbation Training for Salt-Body
Delineation in Gulf of Mexico Seismic Volumes"** (Aham, Gani, Singh & Pahari).

The package trains 3D encoder–decoder networks to segment salt from reverse-time-migrated
(RTM) depth-domain seismic volumes, runs the sequential ablation (Configurations A–G),
fine-tunes the base model with seismic and label perturbation, and applies trained models
to new volumes. It reproduces the configuration used for the results reported in the
manuscript; see [Implementation notes](#implementation-notes) for details that matter when
interpreting or re-running the experiments.

## Repository structure

```
salt3d-gom/
├── train.py               training: ablation, base model, perturbation, ensemble evaluation
├── apply.py               prediction on a volume, optional scoring and geobody extraction
├── salt3d/
│   ├── config.py          all settings used for the reported runs
│   ├── data.py            train/validation split, patch generator, generator wrappers
│   ├── augmentation.py    training-time augmentation
│   ├── perturbation.py    seismic and label perturbation generators
│   ├── losses.py          composite and baseline losses, training metrics
│   ├── models.py          plain 3D U-Net, residual U-Net (± SE), ablation registry
│   ├── callbacks.py       early stopping, LR schedule, checkpoints, per-depth metrics
│   ├── inference.py       sliding-window prediction with Gaussian blending
│   ├── postprocess.py     geobody extraction and surface triangulation
│   ├── evaluation.py      volume and patch metrics
│   └── utils.py           GPU setup, seeding, HDF5/JSON I/O
├── tests/test_smoke.py    end-to-end check on a synthetic volume
└── requirements.txt
```

## Installation

```bash
conda create -n salt3d python=3.10
conda activate salt3d
pip install -r requirements.txt
```

The reported models were trained with TensorFlow 2.10/2.11 (Keras 2). Use TensorFlow
2.10–2.15 to reproduce training exactly. Prediction (`apply.py`) also runs with
TensorFlow ≥ 2.16 (Keras 3); training with depth-bin sample weights requires Keras 2
(see [Implementation notes](#implementation-notes)). Check the installation with:

```bash
python -m tests.test_smoke
```

## Data

The seismic surveys are public through the National Archive of Marine Seismic Surveys
(NAMSS, https://walrus.wr.usgs.gov/namss/). The code expects HDF5 files with a dataset
named `cube`, arranged as (inline, crossline, depth):

| File | Shape | Content |
|---|---|---|
| `data/train_val-vk/seismic.h5` | 1276 × 1760 × 1876 | Viosca Knoll RTM amplitudes, every second stored inline and crossline (50 m), 32 ft (9.75 m) depth samples |
| `data/train_val-vk/salt.h5` | 1276 × 1760 × 1876 | Viosca Knoll salt mask |
| `data/test-mississippi/seismic.h5` | 1201 × 701 × depth | Mississippi Canyon RTM amplitudes, 20 m × 40 m, 32 ft depth samples |
| `data/test-mississippi/mississippi_salt.h5` | same as seismic | Mississippi Canyon salt mask |

The salt masks mark the voxels at the salt-flood velocity, 4,481 m/s (14,700 ft/s), in the
migration velocity model of each survey; this matches the labels used in the manuscript
(IoU 0.997 with the flood velocity over the Viosca Knoll validation region).

> **Data preparation.** Conversion from SEG-Y to HDF5, horizontal subsampling of the
> Viosca Knoll volume and amplitude normalisation were performed before training and are
> not part of this package. `seismic.h5` is used by the training code exactly as stored.
> [TO BE COMPLETED BY THE AUTHORS: describe or add the preparation script.]

## Reproducing the results

All outputs are written under `outputs/` (change with `--out`).

**Table 4 — sequential ablation** (7 configurations × 3 seeds):
```bash
python train.py ablation                         # all configurations and seeds
python train.py ablation --configs A B --seeds 42   # a subset
```
Results: `outputs/ablation/ablation_summary.csv` (mean ± SD over seeds),
per-run checkpoints `outputs/ablation/config_<X>/seed_<S>/best.h5`, histories and
per-depth metrics.

**Table 3 — base model and perturbation fine-tuning:**
```bash
python train.py base                     # Configuration E, seed 42
python train.py perturb --mode seismic
python train.py perturb --mode label
python train.py perturb --mode joint
python train.py ensemble-eval            # 4-model ensemble on the validation patches
```
Each run reports its metrics from the epoch with the highest validation soft Dice
(`outputs/perturbation/<name>_best.json`); the reported models are the
`<name>_best_dice.h5` checkpoints.

**Table 5 — Mississippi Canyon independent test:**
```bash
python apply.py --seismic data/test-mississippi/seismic.h5 \
    --weights outputs/perturbation/base_model_best_dice.h5 \
              outputs/perturbation/seismic_model_best_dice.h5 \
              outputs/perturbation/label_model_best_dice.h5 \
              outputs/perturbation/joint_model_best_dice.h5 \
    --labels data/test-mississippi/mississippi_salt.h5 --save-each \
    --out outputs/mississippi/prob.h5
```
Metrics: `outputs/mississippi/prob_metrics.csv` (soft Dice, IoU, boundary IoU, precision,
recall, false-positive rate) for each model and the ensemble. Every non-zero reference
voxel is salt, inlines without labels are excluded, and the volume is scored to 40,000 ft.

**Ablation configurations on Mississippi Canyon** (e.g. Configuration A, three seeds):
```bash
python apply.py --seismic data/test-mississippi/seismic.h5 --arch plain_unet \
    --weights outputs/ablation/config_A/seed_42/best.h5 \
              outputs/ablation/config_A/seed_123/best.h5 \
              outputs/ablation/config_A/seed_7/best.h5 \
    --labels data/test-mississippi/mississippi_salt.h5 --save-each \
    --out outputs/mississippi/config_A.h5
```
Use `--arch resunet` for Configuration B and `se_resunet` (default) for C–G.

**Viosca Knoll probability volume and geobody** (Figs. 13–14):
```bash
python apply.py --seismic data/train_val-vk/seismic.h5 --weights <four checkpoints> \
    --survey-mask --geobody outputs/vk/geobody.h5 --out outputs/vk/prob.h5
```

## Implementation notes

These describe the code as it was run for the reported results.

- **Validation sampling.** 100 validation patches (13 background) from crosslines
  1105–1759 with stride 64 (50% overlap) and seed 999. Training patches whose footprint
  reaches the last 256 crosslines before the buffer are excluded, which separates the
  nearest training and validation patches by 273 crosslines (≈13.7 km).
- **Fixed patch pools.** Patches are selected once per seed and kept fixed; only their
  order and augmentation change between epochs. Background patches have < 10% salt;
  patches with > 80% salt are excluded.
- **Depth-bin labels as sample weights.** `DataGenerator` returns `(X, Y, depth_labels)`,
  and Keras interprets the third element as sample weights. Because the losses return one
  value per batch, the data term of each batch's training loss is scaled by the mean
  depth-bin index (0 = shallow, 1 = mid, 2 = deep) of its patches; batches of shallow
  patches only contribute no data loss. The compiled metrics, including the validation
  soft Dice used for early stopping, learning-rate reduction and checkpointing, are not
  weighted (verified in the original TensorFlow 2.x environment), so model selection and
  the reported validation metrics are unaffected. The labels are returned as a Python
  list, as in the original runs; Keras 3 rejects this. Pass `--no-depth-sample-weights`
  to train without the weighting (not used for the reported results).
- **Boundary-Dice term.** `get_boundary_mask` thresholds its input, so the boundary-Dice
  term of the composite loss gives no gradient with respect to the prediction (verified:
  0 of 164 weight tensors). It is kept unchanged for reproducibility.
- **Configurations F and G.** Their loss (`salt_ultimate_loss_depth_weighted`) applies
  per-sample depth-bin weights (0.33, 2.0, 0.67) **and** uses term weights
  0.35/0.25/0.20/0.20 and a 10-voxel boundary band, instead of 0.2/0.2/0.3/0.3 and
  3 voxels in Configurations D and E.
- **Seeds.** Seeds fix patch selection, order and the TensorFlow random state. The
  validation generator (seed 999) is created after the training generator and resets
  the global random state, so the three training seeds mainly change background-patch
  selection and order. GPU operations are not deterministic.
- **Perturbation.** Models are initialised from the base model's best checkpoint and
  trained for up to 75 epochs with a new Adam optimiser (learning rate 1e-4). Seismic
  perturbation applies only to shallow (D0) patches; its noise is scaled to the standard
  deviation of the whole batch and the sinusoid runs along the crossline axis.
- **Prediction.** Each patch is re-standardised (z-score, clipped to ±2, divided by 2)
  before prediction; training uses `seismic.h5` values as stored. Patches overlap by 64
  voxels and are blended with a 3D Gaussian taper. `--survey-mask` zeroes predictions
  where the amplitude is exactly 0; Table 5 was computed without it.
- **Postprocessing** (Gaussian smoothing σ = 1.2, thresholds 0.45/0.65, closing,
  hole filling, removal of components < 800,000 voxels), adapted from Wu (2016), is for
  visualisation only; all metrics are computed on raw probabilities.

## Citation

[TO BE COMPLETED: journal reference and DOI once published.]

## License

[TO BE COMPLETED BY THE AUTHORS.]
